#!/usr/bin/env bash
set -euo pipefail

SevenZCMD="../internal/7zz64"
if [ "$(uname -m)" != "x86_64" ]; then
	SevenZCMD="../internal/7zz32"
fi

OutputFile="windows_injection.7z"
[ -f "$OutputFile" ] && rm "$OutputFile"

cd X
"$SevenZCMD" a "../${OutputFile}" . >/dev/null
cd ..

echo
echo
if [ -f "$OutputFile" ]; then
	echo "==============================="
	echo "========== SUCCESS ============"
	echo "==============================="
else
	echo "==============================="
	echo "=========== FAILED ============"
	echo "==============================="
fi
echo
echo

read -p "Press enter to continue"
